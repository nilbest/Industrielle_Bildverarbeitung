clear; clc;
close all;

Kreis_img = imread('Images/Kreis.png');

Gradienten(Kreis_img);