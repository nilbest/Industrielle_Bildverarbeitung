clear; clc;
close all;

Park();