clear; clc;
close all;

TextLocalThresh();