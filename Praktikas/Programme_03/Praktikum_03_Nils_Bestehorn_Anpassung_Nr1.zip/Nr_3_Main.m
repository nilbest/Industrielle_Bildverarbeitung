clear; clc;
close all;

AlphaBlendingFarbe()