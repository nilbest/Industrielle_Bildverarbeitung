clear; clc;
close all;

knnMain();