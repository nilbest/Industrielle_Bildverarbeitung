clear; clc;
close all;

interpolationMain();